package com.loongjoy.imageup;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.media.Image;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import com.nostra13.universalimageloader.cache.disc.impl.UnlimitedDiskCache;
import com.nostra13.universalimageloader.cache.disc.naming.Md5FileNameGenerator;
import com.nostra13.universalimageloader.cache.memory.impl.UsingFreqLimitedMemoryCache;
import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.ImageLoaderConfiguration;
import com.nostra13.universalimageloader.core.assist.QueueProcessingType;
import com.nostra13.universalimageloader.core.download.BaseImageDownloader;
import com.nostra13.universalimageloader.utils.StorageUtils;

import java.io.File;
import java.util.ArrayList;
import java.util.logging.Logger;

/**
 * Created by 陈彬 on 2016/2/23  12:09
 * 方法描述: 点击图片放大
 */
public class MainActivity extends AppCompatActivity {

    private SmoothImageView imageView;
    private Context context;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        context = this;
        initImageLoader();
        imageView = (SmoothImageView) findViewById(R.id.iamge);
        String url = "http://img2.imgtn.bdimg.com/it/u=2842109161,3754761407&fm=21&gp=0.jpg";
        ImageLoader.getInstance().displayImage(url,imageView);
        //点击事件
        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startNewActivity();
            }
        });
    }

    private DisplayImageOptions mNormalImageOptions;
    /**
     * Created by 陈彬 on 2016/2/23  13:44
     * 方法描述: 初始化ImageLoader
     */
    private void initImageLoader() {

        mNormalImageOptions = new DisplayImageOptions.Builder().bitmapConfig(Bitmap.Config.RGB_565).cacheInMemory(true).cacheOnDisc(true)
                .resetViewBeforeLoading(true).build();


        // 自定义缓存路径
        File cacheDir = StorageUtils.getOwnCacheDirectory(context, "loongjoyImage/Cache");
        ImageLoaderConfiguration config = new ImageLoaderConfiguration.Builder(context)
                .memoryCacheExtraOptions(480, 800)
                        // max width, max height内存缓存文件的最大长宽
                .threadPoolSize(3)
                        // 线程池内加载的数量
                .threadPriority(Thread.NORM_PRIORITY - 2)// default 设置当前线程的优先级
                .denyCacheImageMultipleSizesInMemory().diskCacheFileNameGenerator(new Md5FileNameGenerator()) // 将url转换成MD5保存
                .memoryCache(new UsingFreqLimitedMemoryCache(2 * 1024 * 1024)).memoryCacheSize(2 * 1024 * 1024) // 缓存的最大值
                .diskCacheSize(50 * 1024 * 1024) // sd卡(本地)缓存的最大值
                .tasksProcessingOrder(QueueProcessingType.LIFO)
                        // 锟斤拷原锟饺碉拷discCache -> diskCache
                .diskCache(new UnlimitedDiskCache(cacheDir))// default 可以自定义缓存路径
                .imageDownloader(new BaseImageDownloader(context, 5 * 1000, 30 * 1000))
                        // connectTimeout(5s),readTimeout(30 s)
                .writeDebugLogs() // Remove for release app
                .defaultDisplayImageOptions(mNormalImageOptions)
                .build();
        ImageLoader.getInstance().init(config);
    }

    /**
     * Created by 陈彬 on 2016/2/23  12:16
     * 方法描述: 开启一个新的界面
     */
    private void startNewActivity() {
        imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
        Intent intent = new Intent(MainActivity.this, SpaceImageDetailActivity.class);
        int[] location = new int[2];
        imageView.getLocationOnScreen(location);
        intent.putExtra("locationX", location[0]);
        intent.putExtra("locationY", location[1]);
        intent.putExtra("width", imageView.getWidth());
        intent.putExtra("height", imageView.getHeight());
        startActivity(intent);
        overridePendingTransition(0, 0);
    }
}
