package com.example.demo;

import android.os.Bundle;

import java.text.SimpleDateFormat;
import java.util.Date;

import com.example.wighet.AppDateDialog;
import com.example.wighet.AppDateDialog.TimeSelectListenner;

import android.app.Activity;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends Activity implements OnClickListener{

	private Button btn_date;
	private TextView tv_date;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		initView();
	}
	
	
	
	
	private void initView() {
		btn_date = (Button) findViewById(R.id.btn_date);
		tv_date = (TextView) findViewById(R.id.tv_date);
		btn_date.setOnClickListener(this);
		
	}




	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.btn_date:
			showPop();
			break;

		default:
			break;
		}
		
	}

	private String startDate;


	private void showPop() {
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		startDate = format.format(new Date());
		AppDateDialog dateDialog = new AppDateDialog(this, "日期选择", null, null, R.style.alert_dialog, false,
				startDate, new TimeSelectListenner() {

					@Override
					public void callBack(String date) {
						tv_date.setText(date);
					}
				});
		dateDialog.show();
		
	}


}
