package com.example.longjoy.jpushtest;

import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;

import java.util.LinkedHashSet;
import java.util.Set;

import cn.jpush.android.api.JPushInterface;
import cn.jpush.android.api.TagAliasCallback;

public class MainActivity extends AppCompatActivity {

    private static final int MSG_SET_TAGS = 0;
    private static final String TAG = "MainActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setJpushTag(50);
        JPushInterface.setDebugMode(true);
        JPushInterface.init(getApplicationContext());

    }

    private void setJpushTag(int userId) {
        if (userId > 0) {
            Set<String> tagSet = new LinkedHashSet<String>();
            String tag = "chenbin";
            tagSet.add(tag);
            jPushTagHandler.sendMessage(jPushTagHandler.obtainMessage(MSG_SET_TAGS, tagSet));
        }
    }

    private final Handler jPushTagHandler = new Handler() {
        @Override
        public void handleMessage(android.os.Message msg) {
            super.handleMessage(msg);
            switch (msg.what) {

                case MSG_SET_TAGS:
                    JPushInterface.setAliasAndTags(getApplicationContext(),
                            null, (Set<String>) msg.obj, setTagTagsCallback);
                    break;
                default:

            }
        }
    };

    private final TagAliasCallback setTagTagsCallback = new TagAliasCallback() {
        @Override
        public void gotResult(int code, String alias, Set<String> tags) {
            String logs;
            switch (code) {
                case 0:
                    logs = "Set tag and alias success";
                    //AppConfig.jPushfs.edit().putString("flag", tags + "ok");
                    break;

                case 6002:
                    logs = "Failed to set alias and tags due to timeout. Try again after 60s.";
                    jPushTagHandler.sendMessageDelayed(jPushTagHandler.obtainMessage(MSG_SET_TAGS, tags), 1000 * 60);

                    break;

                default:
                    logs = "Failed with errorCode = " + code;
            }
            // Toast.makeText(getApplicationContext(), logs,
            // Toast.LENGTH_SHORT).show();
            Log.e("tag", logs);
        }

    };
}
