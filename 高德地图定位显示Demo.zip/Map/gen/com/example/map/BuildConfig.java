/** Automatically generated file. DO NOT MODIFY */
package com.example.map;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}