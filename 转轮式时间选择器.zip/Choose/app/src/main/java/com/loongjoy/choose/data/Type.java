package com.loongjoy.choose.data;

/**
 * Created by jzxiang on 16/4/21.
 */
public enum Type {
    // 五种选择模式，年月日时分，年月日，时分，月日时分，年月
    ALL,
    YEAR_MONTH_DAY,
    HOURS_MINS,
    MONTH_DAY_HOUR_MIN,
    YEAR_MONTH
}
