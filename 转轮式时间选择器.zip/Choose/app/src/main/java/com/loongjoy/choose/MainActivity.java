package com.loongjoy.choose;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.loongjoy.choose.data.Type;
import com.loongjoy.choose.listener.OnDateSetListener;

public class MainActivity extends AppCompatActivity implements View.OnClickListener, OnDateSetListener {

    private Button btn_button;
    private TimePickerDialog mDialogAll;
    private TimePickerDialog mDialogYearMonth;
    private TimePickerDialog mDialogYearMonthDay;
    private TimePickerDialog mDialogMonthDayHourMinute;
    private TimePickerDialog mDialogHourMinute;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btn_button = (Button) findViewById(R.id.btn_button);
        btn_button.setOnClickListener(this);
        initDailog();
    }

    private void initDailog() {
        mDialogAll = new TimePickerDialog.Builder()
                .setCallBack(this)
                .setCancelStringId("cancel")
                .setSureStringId("sure")
                .setTitleStringId("TimePicker")
                .setCyclic(false)
                .setMinMillseconds(System.currentTimeMillis())
                .setCurrentMillseconds(System.currentTimeMillis())
                .setThemeColor(getResources().getColor(R.color.timepicker_dialog_bg))
                .setType(Type.ALL)
                .setWheelItemTextNormalColor(getResources().getColor(R.color.timetimepicker_default_text_color))
                .setWheelItemTextSelectorColor(getResources().getColor(R.color.timepicker_toolbar_bg))
                .setWheelItemTextSize(12)
                .build();
        mDialogYearMonth = new TimePickerDialog.Builder()
                .setType(Type.YEAR_MONTH)
                .setThemeColor(getResources().getColor(R.color.colorPrimary))
                .setCallBack(this)
                .build();
        mDialogYearMonthDay = new TimePickerDialog.Builder()
                .setType(Type.YEAR_MONTH_DAY)
                .setCallBack(this)
                .build();
        mDialogMonthDayHourMinute = new TimePickerDialog.Builder()
                .setType(Type.MONTH_DAY_HOUR_MIN)
                .setCallBack(this)
                .build();
        mDialogHourMinute = new TimePickerDialog.Builder()
                .setType(Type.HOURS_MINS)
                .setCallBack(this)
                .build();
    }

    @Override
    public void onClick(View v) {
        //弹出菜单
        //mDialogAll.show(getSupportFragmentManager(), "all");
        mDialogYearMonthDay.show(getSupportFragmentManager(), "year_month_day");
    }

    @Override
    public void onDateSet(TimePickerDialog timePickerView, long millseconds) {

    }
}
