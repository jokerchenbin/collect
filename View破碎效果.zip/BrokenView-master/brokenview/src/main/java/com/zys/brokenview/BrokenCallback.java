package com.zys.brokenview;

import android.view.View;

public abstract class BrokenCallback{
    public void onStart(View v) {

    }

    public void onCancel(View v) {

    }

    public void onRestart(View v) {

    }

    public void onFalling(View v) {

    }

    public void onFallingEnd(View v) {

    }

    public void onCancelEnd(View v) {

    }
}
