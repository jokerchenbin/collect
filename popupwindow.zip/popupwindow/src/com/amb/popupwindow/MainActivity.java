package com.amb.popupwindow;

import com.admob.zkapp.covers.Covers;

import android.app.Activity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.ImageView;

public class MainActivity extends Activity {
	private ImageView ivShow;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_main);
		Covers c = new Covers(this, "ab51d5a3cb4d45bbae9e8de9e43a432e");
		ivShow = (ImageView) findViewById(R.id.ivShow);
		ivShow.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				CustomPopupWindow popupWindow = new CustomPopupWindow(MainActivity.this);
				
				popupWindow.showAtDropDownRight(ivShow);
				
			}
		});
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}
}
