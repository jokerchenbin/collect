package szu.wifichat.android.entity;

/**
 * @fileName Entity.java
 * @package szu.wifichat.android.entity
 * @description 实体基类
 */
public class Entity {
	// 本来想做些什么来,暂时空着吧
}
