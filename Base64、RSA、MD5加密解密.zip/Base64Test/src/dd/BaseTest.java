package dd;

public class BaseTest {

	public static void main(String[] args) {
		String temp = "TWFu";
		String result = "";
		byte [] b ;
		//result = Base64.encode(temp.getBytes());
		b = Base64.decode(temp);
		result = new String(b);
		/*for (int i = 0; i < b.length; i++) {
			result = result+b[i];
		}*/
		
		System.out.println(result);
	}

}
