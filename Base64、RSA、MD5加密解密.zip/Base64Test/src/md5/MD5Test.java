package md5;

public class MD5Test {

	public static void main(String[] args) {
		String name = "陈彬";
		System.out.println("原始  =  " + name);
		
		String temp = Md5Utils.MD5(name);
		System.out.println("加密后  = "+temp);
		
		temp = Md5Utils.MD5(temp);
        System.out.println("第二次加密  =  " + temp);
        
        temp = Md5Utils.convertMD5(temp);
        System.out.println("第二次解密  =  " + temp);

	}

}
