package com.loongjoy.gridviewpic;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;

import java.util.ArrayList;

/**
 * 类描述：
 * 创建人：陈彬
 * 创建时间：2016/6/3 16:25
 */
public class Adapter extends BaseAdapter {

    private Context context;
    private ArrayList<Bitmap> mList;


    public Adapter(Context context) {
        this.context = context;
        this.mList = new ArrayList<>();
    }

    public int getListSize(){
        return mList.size();
    }
    /**
     * 添加图片
     *
     * @param bitmap
     */
    public void addBitmap(Bitmap bitmap) {
        mList.add(bitmap);
        notifyDataSetChanged();
    }


    @Override
    public int getCount() {
        if (mList == null) {
            return 1;
        }
        return mList.size() + 1;
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View view = LayoutInflater.from(context).inflate(R.layout.item, parent, false);
        ImageView iv_iamge = (ImageView) view.findViewById(R.id.imageView);
        //绑定数据
        Log.v("chenbin", getCount() + " = = = " + position);
        if (getCount() != 1 && position < mList.size()) {
            iv_iamge.setImageBitmap(mList.get(position));
        }

        return view;
    }
}
