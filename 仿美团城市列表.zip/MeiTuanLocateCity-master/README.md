# MeiTuanLocateCity
仿美团城市选择界面，可直接用在实际项目中

![image](https://github.com/yangxu4536/MeiTuanLocateCity/raw/master/screenshots/1.jpg)
![image](https://github.com/yangxu4536/MeiTuanLocateCity/raw/master/screenshots/2.jpg)
![image](https://github.com/yangxu4536/MeiTuanLocateCity/raw/master/screenshots/3.jpg)
