/** Automatically generated file. DO NOT MODIFY */
package com.droid;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}