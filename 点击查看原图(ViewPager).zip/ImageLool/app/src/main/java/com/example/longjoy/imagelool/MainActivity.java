package com.example.longjoy.imagelool;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //http://img4.imgtn.bdimg.com/it/u=3233739702,2923477304&fm=21&gp=0.jpg
    }


    public void onViewClick(View view){
        Intent intent = new Intent(MainActivity.this,ImageBrowseActivity.class);
        String image_url = "http://img4.imgtn.bdimg.com/it/u=3233739702,2923477304&fm=21&gp=0.jpg";
        intent.putExtra("image",image_url);
        startActivity(intent);
    }
}
