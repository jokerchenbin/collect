package com.example.longjoy.imagelool;

import android.app.Application;

import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.ImageLoaderConfiguration;


public class AppApplication extends Application {

	@Override
	public void onCreate() {
		super.onCreate();
		ImageLoaderConfiguration config=new ImageLoaderConfiguration.Builder(getApplicationContext())
				.memoryCacheSizePercentage(30)
				.build();
		ImageLoader.getInstance().init(config);
	}

}
