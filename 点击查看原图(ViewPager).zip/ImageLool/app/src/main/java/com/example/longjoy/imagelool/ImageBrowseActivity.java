package com.example.longjoy.imagelool;

import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoader;

import java.util.ArrayList;

public class ImageBrowseActivity extends AppCompatActivity {

    private String image_url;
    private ImageView iamge;
    private DisplayImageOptions options;
    private ViewPager pager;
    private String [] image_url_str;
    private ArrayList<View> list;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_image_browse);

        image_url_str = new String[]{"http://img4.imgtn.bdimg.com/it/u=3233739702,2923477304&fm=21&gp=0.jpg",
                                       "http://img3.imgtn.bdimg.com/it/u=1183223528,3058066243&fm=21&gp=0.jpg",
                "http://baike.soso.com/p/20090711/20090711101754-314944703.jpg",
                "http://img2.3lian.com/img2007/19/33/005.jpg"};

        options=new DisplayImageOptions.Builder()
                .cacheInMemory(true)
                .showImageForEmptyUri(R.mipmap.ic_launcher)
                .cacheOnDisk(true)
                .showImageOnFail(R.mipmap.ic_launcher)
                .build();

        list = new ArrayList<>();
        for (int i = 0; i<image_url_str.length;i++){
            View view = LayoutInflater.from(this).inflate(R.layout.item,null);
            ImageView iamge = (ImageView) view.findViewById(R.id.item_image);
            ImageLoader.getInstance().displayImage(image_url_str[i],iamge,options);
            list.add(view);
        }
        pager = (ViewPager) findViewById(R.id.activity_image_browse_iv_image);

        ImageAdapter adapter = new ImageAdapter(list,this);

        pager.setAdapter(adapter);
        pager.addOnPageChangeListener(new PageChangeListener());


    }


    private class PageChangeListener implements ViewPager.OnPageChangeListener {

        @Override
        public void onPageScrollStateChanged(int arg0) {

        }

        @Override
        public void onPageScrolled(int arg0, float arg1, int arg2) {

        }

        @Override
        public void onPageSelected(int arg0) {

        }

    }
}
