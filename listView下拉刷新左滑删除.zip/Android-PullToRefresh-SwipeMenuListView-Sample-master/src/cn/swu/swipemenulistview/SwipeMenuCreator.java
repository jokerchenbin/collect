package cn.swu.swipemenulistview;

public interface SwipeMenuCreator {

    void create(SwipeMenu menu);
}
